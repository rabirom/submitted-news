import requests
import feedparser
import random
import time
import json
import re
import signal
import os
from pathlib import Path
from datetime import datetime

# =====================
# CONFIGURATION
# =====================

BASE_DIR = Path(__file__).resolve().parent
FEEDS_FILE = BASE_DIR / "feeds.json"
SEEN_TITLES_FILE = BASE_DIR / "seen_titles.json"
SEEN_TOPICS_FILE = BASE_DIR / "seen_topics.json"

# Supply credentials through environment variables; never commit secrets.
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
WP_BASE = os.getenv("WP_BASE", "https://submitted.news/wp-json/wp/v2").rstrip("/")
WP_USER = os.getenv("WP_USER", "")
WP_APP_PASSWORD = os.getenv("WP_APP_PASSWORD", "")

FETCH_PER_FEED = 3
NEWS_PER_RUN = 8   # increase slowly (safe scaling)

# =====================
# GLOBAL TIMEOUT
# =====================

def timeout_handler(signum, frame):
    raise Exception("SCRIPT TIMEOUT")

signal.signal(signal.SIGALRM, timeout_handler)
signal.alarm(240)

# =====================
# LOAD / SAVE
# =====================

def load_json(file):
    try:
        with open(file, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except:
        return set()

def save_json(file, data):
    with open(file, "w", encoding="utf-8") as f:
        json.dump(list(data), f)

# =====================
# NORMALIZE (TOPIC DEDUPE)
# =====================

def normalize(text):
    text = text.lower()
    text = re.sub(r'[^a-z0-9 ]', '', text)
    return " ".join(text.split()[:8])

# =====================
# FILTER
# =====================

KEYWORDS = [
    "ai", "artificial intelligence", "chatgpt",
    "openai", "google", "meta", "microsoft",
    "nvidia", "startup", "technology"
]

def is_relevant(title, summary):
    text = (title + " " + summary).lower()
    return any(k in text for k in KEYWORDS)

# =====================
# LOAD FEEDS
# =====================

def load_feeds():
    with open(FEEDS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

# =====================
# OPENAI
# =====================

def generate(prompt):
    try:
        r = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
            json={
                "model": "gpt-4o-mini",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 500
            },
            timeout=10
        )

        if r.status_code != 200:
            return None

        return r.json()["choices"][0]["message"]["content"]

    except:
        return None

# =====================
# 🔥 DAN HARMON STORY PROMPT (FINAL)
# =====================

def news_prompt(title, summary):
    return f"""
Write a tech news article using Dan Harmon's Story Circle internally.

DO NOT mention story structure.

Flow:
1. Start with current situation (what was normal)
2. Introduce change or conflict
3. Explain what happened next (facts)
4. Show impact or consequence

Rules:
- MUST include <h1>
- No labels like "what changed"
- No repetition
- No fluff
- No generic phrases

Style:
- Clean journalism tone
- Short sentences
- Human readable

Structure:
- 4 paragraphs
- 2–3 sentences each

INPUT:
Title: {title}
Summary: {summary}

OUTPUT:

<h1>Specific strong headline</h1>
<p>Paragraph 1</p>
<p>Paragraph 2</p>
<p>Paragraph 3</p>
<p>Paragraph 4</p>
"""

# =====================
# CLEAN CONTENT
# =====================

def clean_content(text):
    text = re.sub(r"<html.*?>.*?</html>", "", text, flags=re.S)

    # remove markdown links
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)

    # remove urls
    text = re.sub(r'http[s]?://\S+', '', text)

    text = text.replace("**", "")
    text = re.sub(r"\s+", " ", text)

    return text.strip()

# =====================
# TITLE EXTRACTION
# =====================

def extract_title_and_clean(content):
    match = re.search(r"<h1>(.*?)</h1>", content)

    if match:
        title = match.group(1)
        content = re.sub(r"<h1>.*?</h1>", "", content, count=1)
    else:
        text = re.sub('<.*?>', '', content)
        sentences = [s.strip() for s in text.split('.') if len(s.strip()) > 30]
        title = sentences[0][:90] if sentences else "Latest Tech News"

    return title.strip(), content.strip()

# =====================
# FETCH
# =====================

def fetch_articles():
    feeds = load_feeds()
    articles = []

    for f in feeds:
        try:
            parsed = feedparser.parse(f["url"])
            if not parsed.entries:
                continue

            for e in parsed.entries[:FETCH_PER_FEED]:
                title = e.title
                summary = e.get("summary", "")

                if is_relevant(title, summary):
                    articles.append({
                        "title": title,
                        "summary": summary
                    })
        except:
            continue

    random.shuffle(articles)
    return articles

# =====================
# WORDPRESS
# =====================

def publish(title, content):
    try:
        r = requests.post(
            WP_BASE + "/posts",
            json={
                "title": title,
                "content": content,
                "status": "publish"
            },
            auth=(WP_USER, WP_APP_PASSWORD),
            timeout=10
        )
        return r.status_code == 201
    except:
        return False

# =====================
# MAIN
# =====================

def run():
    try:
        missing = [name for name, value in {
            "OPENAI_API_KEY": OPENAI_API_KEY,
            "WP_USER": WP_USER,
            "WP_APP_PASSWORD": WP_APP_PASSWORD,
        }.items() if not value]
        if missing:
            raise RuntimeError("Missing required environment variables: " + ", ".join(missing))

        print("RUN START:", datetime.now())

        seen_titles = load_json(SEEN_TITLES_FILE)
        seen_topics = load_json(SEEN_TOPICS_FILE)

        articles = fetch_articles()
        print("Fetched:", len(articles))

        count = 0

        for a in articles:

            if count >= NEWS_PER_RUN:
                break

            raw_title = a["title"].strip().lower()
            topic_key = normalize(raw_title)

            if raw_title in seen_titles:
                continue

            if topic_key in seen_topics:
                continue

            print("Processing:", a["title"])

            raw = generate(news_prompt(a["title"], a["summary"]))
            if not raw:
                continue

            content = clean_content(raw)
            title, content = extract_title_and_clean(content)

            if not title or len(title) < 15:
                continue

            if publish(title, content):
                print("PUBLISHED:", title)

                seen_titles.add(raw_title)
                seen_topics.add(topic_key)

                save_json(SEEN_TITLES_FILE, seen_titles)
                save_json(SEEN_TOPICS_FILE, seen_topics)

                count += 1

            time.sleep(random.uniform(2, 4))

        print("RUN END:", count)

    except Exception as e:
        print("ERROR:", str(e))

# =====================
# RUN
# =====================

if __name__ == "__main__":
    run()