# Submitted News — Publishing Automation

Live website: https://aliceblue-antelope-926456.hostingersite.com/

This project supports Submitted News, currently hosted at the live website above. This repository contains the Python RSS-to-WordPress publishing automation recovered from the server backup. WordPress stores page/post content, menus, settings, and many plugin settings in its database, so this is **not** a complete portable copy of the entire WordPress site or its visual theme. It does not contain WordPress core, the production database, uploads, secrets, or the v0/Next.js frontend source.

## What it does

- Reads RSS feed URLs from `feeds.json`.
- Filters stories for technology and AI relevance.
- Uses the OpenAI API to draft an article.
- Publishes the article through the WordPress REST API.
- Stores seen titles/topics locally to reduce duplicates.

## Setup

Requires Python 3.10 or newer.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

Set the values from `.env` as environment variables in your terminal or hosting scheduler before running the script. The script intentionally does not read `.env` automatically; use your host's secret/environment-variable settings, or add a vetted dotenv loader if desired. Never commit credentials.

```bash
export OPENAI_API_KEY='your-key'
export WP_BASE='https://YOUR-WEBSITE/wp-json/wp/v2'  # Replace with your WordPress site's REST API base URL
export WP_USER='your-wordpress-username'
export WP_APP_PASSWORD='your-wordpress-application-password'
python news_engine.py
```

On Windows PowerShell, use `$env:OPENAI_API_KEY="your-key"` etc.

## Important safety notes

- Review every generated article before enabling unattended publishing.
- Use a dedicated WordPress account with only the permissions needed to publish posts.
- Keep API keys and WordPress application passwords in environment variables or your hosting provider's secret manager.
- The `seen_titles.json` and `seen_topics.json` files are runtime state and are intentionally excluded from version control.
- The repository does not include WordPress core, database content, uploads, plugins, or the v0 frontend source.
